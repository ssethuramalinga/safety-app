# Assets Directory

This directory contains app assets. Before building, you need to add:

## Required Files

### App Icon
- **File:** `icon.png`
- **Size:** 1024x1024 pixels
- **Format:** PNG with transparency
- **Description:** Your app icon (purple shield or safety symbol recommended)

### Splash Screen
- **File:** `splash.png`
- **Size:** 1284x2778 pixels (iPhone 14 Pro Max)
- **Format:** PNG
- **Background:** #5B4FE9 (purple)
- **Description:** Launch screen shown while app loads

## Optional Assets

### Audio (for AI voices)
```
assets/audio/
├── female_casual_1.mp3
├── female_casual_2.mp3
├── female_concerned_1.mp3
├── male_casual_1.mp3
└── ...
```

### Images
```
assets/images/
├── blue-light-icon.png
├── police-icon.png
└── logo.png
```

### Fonts (if using custom fonts)
```
assets/fonts/
├── CustomFont-Regular.ttf
└── CustomFont-Bold.ttf
```

## Generating Assets

### Quick Start Icons
Use Expo's icon generator:
```bash
npx expo-icon --foreground ./my-icon.png --background '#5B4FE9'
```

### Design Tools
- **Figma** - Design icons/splash screens
- **Canva** - Quick templates
- **Icon Kitchen** - Generate Android/iOS icons

### Recommended Icon
- Purple shield with phone/location symbol
- Emergency SOS symbol
- Safety-related imagery
- Keep it simple and recognizable

## Current Status
- ⚠️ Placeholder files needed
- Add icon.png and splash.png before building
- Audio files optional (can use ElevenLabs API)
