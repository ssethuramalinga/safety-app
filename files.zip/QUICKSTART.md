# Quick Start Guide - Safety App Settings

Get up and running in 5 minutes!

## 🚀 Fast Setup (5 minutes)

### Step 1: Install Dependencies (2 min)
```bash
cd safety-app-settings
npm install
```

### Step 2: Set Up Expo (1 min)
```bash
# Install Expo CLI globally if you haven't
npm install -g expo-cli

# Start the development server
npm start
```

### Step 3: Run on iOS Device (2 min)
- **Physical iPhone:** Scan QR code with Camera app
- **Simulator:** Press `i` in terminal
- **Xcode:** `open ios/SafetyApp.xcworkspace` then press ⌘R

**Note:** For full functionality (SMS, shake detection, haptics), use a physical iPhone.

## 📱 Required Permissions

The app will request these permissions on first use:
- ✅ **Contacts** - To add emergency contacts
- ✅ **SMS** - To send test alerts (requires cellular plan)
- ✅ **Motion/Sensors** - For shake gesture detection
- ✅ **Location** - For emergency location sharing
- ✅ **Face ID/Touch ID** - To secure settings (optional)

**Grant all permissions when prompted for full functionality.**

**iOS Tip:** You can review/change permissions in Settings → SafetyApp

## 🎯 Key Features Tour (Try These First)

### 1. Add Your First Emergency Contact (30 seconds)
```
Settings → Emergency Contacts → + Add Contact
→ Pick from Contacts → Select someone → Save
```

### 2. Test the Gesture Detection (1 minute)
```
Settings → SafeSignal Gesture → Select "Shake phone"
→ ▶️ Practice Gesture → Shake phone 3 times rapidly
✅ Should see "Gesture Detected!" message
```

### 3. Customize Alert Message (30 seconds)
```
Settings → Alert Message Templates
→ Edit default message → Add [LOCATION] variable
→ Save Default Message
```

### 4. Try a Decoy Screen (30 seconds)
```
Settings → Decoy Screen → Select "Calculator"
→ 👁️ Try Decoy Screen → Tap corner 3x to exit
```

## 🧪 Quick Test Checklist

Run these 5 tests to verify everything works:

- [ ] Add a contact and send test SMS
- [ ] Detect shake gesture in practice mode
- [ ] Preview AI voice (any type/tone)
- [ ] View calculator decoy and exit
- [ ] Save settings and restart app (settings persist)

## 📂 Project Structure

```
📁 safety-app-settings/
├── 📄 App.js                          # Main app with tab navigation
├── 📄 SettingsScreen.js               # Settings container
├── 📁 components/
│   ├── EmergencyContactsSection.js   # ✅ Add/edit/delete contacts
│   ├── SafeSignalGestureSection.js   # ✅ Gesture detection
│   ├── AlertTemplatesSection.js      # ✅ Message customization
│   ├── VoiceSettingsSection.js       # ✅ AI voice config
│   ├── DecoyScreenSection.js         # ✅ Decoy screens
│   └── PrivacySection.js             # ✅ Privacy controls
├── 📁 services/
│   └── GestureDetectionService.js    # Background gesture monitoring
└── 📄 package.json                    # Dependencies
```

## ⚙️ Configuration

### Environment Variables (Optional)
Create `.env` file:
```bash
ELEVENLABS_API_KEY=your_api_key_here
TWILIO_ACCOUNT_SID=your_sid_here
TWILIO_AUTH_TOKEN=your_token_here
```

### Customization Options

**Change App Theme:**
Edit `SettingsScreen.js`:
```javascript
const PRIMARY_COLOR = '#5B4FE9';  // Change to your brand color
```

**Adjust Shake Sensitivity:**
Edit `SafeSignalGestureSection.js`:
```javascript
const SHAKE_THRESHOLD = 2.5;  // Lower = more sensitive (1.5-3.5)
```

**Modify Contact Limit:**
Edit `EmergencyContactsSection.js`:
```javascript
if (contacts.length >= 5) // Change 5 to your limit
```

## 🐛 Common Issues & Fixes

### Issue: "Cannot find module '@react-native-async-storage/async-storage'"
**Fix:**
```bash
npm install
cd ios && pod install && cd ..
expo start --clear
```

### Issue: Gesture detection not working
**Fix:**
1. Must test on physical iPhone (not simulator)
2. Check Settings → SafetyApp → Motion & Fitness → ON
3. Grant motion permissions when prompted
4. Restart app after granting permissions

### Issue: SMS test fails
**Fix:**
1. Must test on physical iPhone with active cellular plan
2. Check that device can send regular SMS
3. Verify phone number format: +1 (555) 123-4567
4. SMS doesn't work in iOS Simulator

### Issue: Contacts not loading
**Fix:**
1. Settings → SafetyApp → Contacts → Allow
2. Grant permission when prompted
3. Restart app after granting permission

### Issue: Settings not persisting
**Fix:**
```bash
# Clear cache and AsyncStorage
expo start --clear
# Or delete app and reinstall
```

### Issue: "Could not find iPhone"
**Fix:**
1. Unlock iPhone
2. Trust this computer (popup on iPhone)
3. Reconnect Lightning/USB-C cable
4. In Xcode: Window → Devices and Simulators

## 📚 Next Steps

### For Developers
1. **Read IOS_SETUP.md** - Complete iOS deployment guide
2. **Read full README.md** - Detailed documentation
3. **Review TESTING_GUIDE.md** - Complete test cases
4. **Implement Home & Map screens** - Replace placeholders in App.js
5. **Add ElevenLabs integration** - Real AI voices
6. **Configure Face ID** - Secure settings access
7. **TestFlight Beta** - Test with real users
8. **Submit to App Store** - Launch!

### For Testers
1. **Follow TESTING_GUIDE.md** - All 56 test cases
2. **Test on multiple iPhones** - iPhone 8, X, 11, 12, 13, 14, 15
3. **Test with Face ID enabled** - Security features
4. **Verify edge cases** - Network loss, low battery, etc.

### For Product Managers
1. **Review IOS_SETUP.md** - Deployment strategy
2. **Review feature completeness** - All checkboxes in README
3. **Plan TestFlight beta** - 50-100 testers
4. **Prepare App Store assets** - Screenshots, description
5. **TestFlight feedback loop** - Iterate based on feedback

## 🆘 Need Help?

**Documentation:**
- 📖 Full README: `README.md`
- 🧪 Testing Guide: `TESTING_GUIDE.md`

**Support:**
- Report bugs via GitHub Issues
- Contact development team
- Check Expo documentation: https://docs.expo.dev

## ✅ Success Checklist

You're ready to start developing when:
- [ ] `npm start` runs without errors
- [ ] App loads on your device
- [ ] You can add a contact
- [ ] Gesture detection works in practice mode
- [ ] All 5 tests in Quick Test pass

**Estimated total setup time: 5-10 minutes**

---

🎉 **You're all set!** Start building amazing safety features!
