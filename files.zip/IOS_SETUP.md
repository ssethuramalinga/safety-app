# iOS Setup & Deployment Guide

Complete guide for building and deploying the Safety App on iOS.

## 📱 iOS Requirements

### Development
- **macOS** 12.0 (Monterey) or later
- **Xcode** 14.0 or later
- **iOS Device** running iOS 13.0 or later (recommended for testing)
- **Apple Developer Account** (free for testing, $99/year for App Store)

### Device Compatibility
- ✅ iPhone 8 and later (recommended)
- ✅ iOS 13.0 and later
- ✅ Required: Accelerometer, SMS capability
- ⚠️ Face ID/Touch ID (optional but recommended)

## 🚀 Quick Setup (iOS Only)

### Step 1: Install Dependencies
```bash
cd safety-app
npm install
```

### Step 2: Install CocoaPods (iOS Dependencies)
```bash
cd ios
pod install
cd ..
```

### Step 3: Open in Xcode
```bash
open ios/SafetyApp.xcworkspace
```

### Step 4: Configure Signing
1. Select your project in Xcode
2. Go to "Signing & Capabilities"
3. Select your Team
4. Xcode will automatically generate provisioning profile

### Step 5: Run on Device
```bash
# Via Expo
npm run ios

# Or in Xcode: Product → Run (⌘R)
```

## 📋 Info.plist Configuration

The `ios/Info.plist` file is already configured with all required permissions:

### Required Permissions
```xml
✅ NSContactsUsageDescription - Add emergency contacts
✅ NSLocationWhenInUseUsageDescription - Share location in emergencies
✅ NSLocationAlwaysUsageDescription - Background location for Walking Mode
✅ NSMotionUsageDescription - Detect shake gestures
✅ NSFaceIDUsageDescription - Secure settings with biometrics
```

### Background Modes
```xml
✅ location - Track location in Walking Mode
✅ fetch - Background updates
✅ processing - Handle emergency alerts
```

## 🔐 iOS-Specific Features

### 1. Taptic Engine (Haptic Feedback)
Better haptic feedback than Android:
```javascript
// Light tap
Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

// Medium tap (gesture detection)
Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

// Heavy tap
Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);

// Success notification
Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

// Warning notification
Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);

// Error notification
Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
```

### 2. Face ID / Touch ID
Already supported for securing settings:
```javascript
import * as LocalAuthentication from 'expo-local-authentication';

// Check if biometrics available
const hasHardware = await LocalAuthentication.hasHardwareAsync();
const isEnrolled = await LocalAuthentication.isEnrolledAsync();

// Authenticate
const result = await LocalAuthentication.authenticateAsync({
  promptMessage: 'Unlock Emergency Settings',
  fallbackLabel: 'Use Passcode',
});
```

### 3. Emergency SOS Integration
Can integrate with iOS Emergency SOS:
```javascript
// Detect when user triggers Emergency SOS (5x power button)
// Your app can add to this flow
```

### 4. Shortcuts Integration
Add Siri Shortcuts:
```javascript
import { donateShortcut } from 'expo-shortcuts';

// Create "I feel unsafe" shortcut
donateShortcut({
  title: 'Activate Safety Alert',
  persistentIdentifier: 'safety-alert',
  suggestedInvocationPhrase: 'I feel unsafe',
});
```

## 🧪 iOS Testing Checklist

### On Physical iPhone (Required)
- [ ] Shake gesture detection works
- [ ] Taptic feedback feels responsive
- [ ] SMS alerts send successfully
- [ ] Location services accurate
- [ ] Face ID/Touch ID works (if available)
- [ ] Works with phone in pocket
- [ ] Background gesture detection active
- [ ] Decoy screens look realistic

### iOS-Specific Tests
- [ ] Test on iPhone 8, X, 11, 12, 13, 14, 15
- [ ] Test with Face ID enabled
- [ ] Test with Touch ID enabled
- [ ] Test in Low Power Mode
- [ ] Test with Airplane Mode (SMS fails gracefully)
- [ ] Test with Location Services off (prompts correctly)
- [ ] Test after app restart
- [ ] Test with app in background

### Simulator Limitations
⚠️ **These features DON'T work in iOS Simulator:**
- SMS sending
- Accelerometer (shake detection)
- Taptic Engine
- Face ID/Touch ID (can simulate but not feel)
- Background location

**Always test on a real iPhone!**

## 📦 Building for TestFlight

### Step 1: Update App Information
Edit `app.json`:
```json
{
  "expo": {
    "name": "SafetyApp",
    "slug": "safety-app",
    "version": "1.0.0",
    "ios": {
      "bundleIdentifier": "com.yourcompany.safetyapp",
      "buildNumber": "1",
      "supportsTablet": false,
      "infoPlist": {
        "NSContactsUsageDescription": "...",
        "NSLocationWhenInUseUsageDescription": "..."
      }
    }
  }
}
```

### Step 2: Build with EAS
```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo
eas login

# Configure build
eas build:configure

# Build for TestFlight
eas build --platform ios --profile production

# Submit to App Store
eas submit --platform ios
```

### Step 3: TestFlight Distribution
1. Build completes (10-20 minutes)
2. Download and upload to App Store Connect
3. Add beta testers in TestFlight
4. Send invites
5. Collect feedback

## 🍎 App Store Submission

### App Store Requirements
1. **App Privacy** - Declare data collection:
   - Contacts (for emergency contacts)
   - Location (for emergency alerts)
   - Device ID (for analytics)

2. **App Store Description** - Focus on safety:
   ```
   Stay safe with discreet emergency alerts. Shake your phone 
   to silently notify trusted contacts with your location. 
   Perfect for walking alone, ride shares, or any situation 
   where you feel unsafe.
   ```

3. **Screenshots Required**:
   - 6.7" (iPhone 15 Pro Max) - 3 screenshots minimum
   - 6.5" (iPhone 14 Plus) - recommended
   - 5.5" (iPhone 8 Plus) - optional

4. **App Review Notes**:
   ```
   Test Account: test@safetyapp.com
   Password: TestPassword123
   
   Test emergency contact: +1 (555) 123-4567
   
   To test shake gesture:
   1. Add emergency contact
   2. Go to SafeSignal Gesture section
   3. Tap "Practice Gesture"
   4. Shake device 3 times
   ```

### Age Rating
- **4+** (No objectionable content)
- Medical/Treatment Information: No
- Realistic Violence: No
- Frequent/Intense: None

### Categories
- **Primary:** Lifestyle
- **Secondary:** Health & Fitness

## 🔧 iOS Optimization Tips

### 1. Reduce App Size
```bash
# Enable bitcode
# Enable app thinning
# Remove unused assets
```

### 2. Battery Optimization
```javascript
// Only track location when Walking Mode active
// Stop accelerometer when not needed
// Use significant location changes instead of continuous
```

### 3. Performance
```javascript
// Use iOS-native components
// Optimize images with WebP
// Enable Hermes JS engine
```

### 4. Accessibility
```swift
// VoiceOver support
accessibilityLabel = "Emergency Contact Button"
accessibilityHint = "Adds a trusted contact for emergencies"

// Dynamic Type support
// High contrast mode
// Reduce motion
```

## 🐛 Common iOS Issues

### Issue: "Could not find iPhone"
**Fix:**
```bash
# Reconnect iPhone
# Trust this computer on iPhone
# Restart Xcode
xcrun simctl erase all
```

### Issue: "Code signing failed"
**Fix:**
1. Xcode → Preferences → Accounts → Download Manual Profiles
2. Clean Build Folder (⌘⇧K)
3. Rebuild

### Issue: Shake detection not working
**Fix:**
- Must test on physical device (not simulator)
- Check motion permissions granted
- Restart app after granting permissions

### Issue: SMS not sending
**Fix:**
- Test on device with active cellular plan
- Check phone number format: +1 (555) 123-4567
- Ensure device can send SMS normally

### Issue: Background location not working
**Fix:**
1. Info.plist has NSLocationAlwaysUsageDescription
2. Request "Always Allow" location permission
3. Enable Background Modes → Location updates

## 📊 iOS Analytics & Monitoring

### Crash Reporting (Sentry)
```bash
npm install @sentry/react-native

# Configure for iOS
npx @sentry/wizard -i reactNative -p ios
```

### Performance (Firebase)
```bash
npm install @react-native-firebase/app
npm install @react-native-firebase/perf

cd ios && pod install
```

### Usage Analytics (Mixpanel)
```bash
npm install mixpanel-react-native
```

## 🎯 iOS-Specific Launch Checklist

Before App Store submission:
- [ ] All permissions properly explained
- [ ] Face ID/Touch ID working
- [ ] Shake detection accurate on all iPhone models
- [ ] Taptic feedback feels natural
- [ ] App Store screenshots captured
- [ ] Privacy policy page added
- [ ] Terms of service added
- [ ] Support email configured
- [ ] Beta tested with 10+ users
- [ ] No crashes in Xcode Organizer
- [ ] Battery impact tested (< 5% per hour)

## 🚀 iOS Launch Strategy

### Phase 1: TestFlight Beta (2 weeks)
- Invite 50-100 beta testers
- Focus on college students
- Collect feedback via TestFlight

### Phase 2: App Store Launch
- Submit for review (3-5 days)
- Launch with PR campaign
- Target college campuses

### Phase 3: Optimization
- Monitor crash reports
- Optimize battery usage
- Add iOS-specific features:
  - Live Activities
  - Dynamic Island
  - Apple Watch app
  - Shortcuts integration

---

**iOS-Only Benefits:**
✅ Better hardware integration (Taptic Engine)
✅ More reliable gesture detection
✅ Superior Face ID/Touch ID
✅ Stronger App Store presence
✅ Higher perceived safety/trust
✅ Apple Watch potential

**You're ready to build the safest app on iOS! 🛡️**
