# Testing Guide - Safety App Settings

Complete testing instructions to verify all features work correctly.

## 🧪 Test Environment Setup

### Required Hardware
- Physical device (iPhone or Android) for full gesture testing
- Test phone numbers for SMS testing
- Active internet connection for contact syncing

### Test Data Preparation
1. Create 3-5 test contacts in your phone
2. Have 2-3 phone numbers available for SMS testing
3. Enable all necessary permissions before testing

## 📋 Detailed Test Cases

### TEST SUITE 1: Emergency Contacts

#### TC-001: Add Contact from Phone
**Steps:**
1. Open Settings page
2. Tap "+ Add Emergency Contact"
3. Tap "📱 Pick from Contacts"
4. Grant contacts permission if prompted
5. Select a contact from the list
6. Add relationship (e.g., "Sister")
7. Tap "Save"

**Expected Result:**
- Contact appears in the list with name, phone, relationship
- Auto-notify toggle is ON by default
- Success alert displays

**Status:** [ ] Pass [ ] Fail

---

#### TC-002: Add Contact Manually
**Steps:**
1. Tap "+ Add Emergency Contact"
2. Enter name: "Test Contact"
3. Enter phone: "(555) 123-4567"
4. Enter relationship: "Friend"
5. Tap "Save"

**Expected Result:**
- Contact saves successfully
- All fields display correctly
- Can add up to 5 contacts total

**Status:** [ ] Pass [ ] Fail

---

#### TC-003: Edit Existing Contact
**Steps:**
1. Find existing contact in list
2. Tap "Edit" button
3. Change name to "Updated Name"
4. Change relationship
5. Tap "Save"

**Expected Result:**
- Changes save immediately
- Updated info displays in list
- No duplicate entries created

**Status:** [ ] Pass [ ] Fail

---

#### TC-004: Delete Contact
**Steps:**
1. Find contact in list
2. Tap "✕" button in top right
3. Confirm deletion

**Expected Result:**
- Confirmation dialog appears
- After confirming, contact removed from list
- Other contacts remain unchanged

**Status:** [ ] Pass [ ] Fail

---

#### TC-005: Test Alert SMS
**Steps:**
1. Add a contact with YOUR phone number
2. Tap "Test Alert" button
3. Check your phone messages

**Expected Result:**
- SMS received within 5 seconds
- Message reads: "This is a test alert from your SafetyApp..."
- Success alert shows in app

**Status:** [ ] Pass [ ] Fail

---

#### TC-006: Contact Limit
**Steps:**
1. Add 5 contacts
2. Try to add a 6th contact

**Expected Result:**
- Alert displays: "You can only add up to 5 emergency contacts"
- 6th contact is not added
- Add button disabled or shows limit message

**Status:** [ ] Pass [ ] Fail

---

#### TC-007: Auto-Notify Toggle
**Steps:**
1. Toggle auto-notify OFF for a contact
2. Close and reopen app
3. Check toggle state

**Expected Result:**
- Toggle state persists after app restart
- Can toggle ON/OFF for each contact independently

**Status:** [ ] Pass [ ] Fail

---

### TEST SUITE 2: SafeSignal Gesture Detection

#### TC-101: Select Shake Gesture
**Steps:**
1. Tap "Shake phone rapidly" option
2. Read the tip message

**Expected Result:**
- Radio button selected
- Tip appears explaining how to use
- Selection persists after app restart

**Status:** [ ] Pass [ ] Fail

---

#### TC-102: Practice Mode - Shake Detection
**Steps:**
1. Select shake gesture
2. Tap "▶️ Practice Gesture"
3. Shake phone back and forth 3 times quickly
4. Observe feedback

**Expected Result:**
- "Practice Mode Active" alert appears
- Counter shows: "Shake detected: 1/3", "2/3", "3/3"
- Haptic vibration on each shake
- "✅ Gesture Detected!" alert after 3 shakes
- No actual SMS sent

**Status:** [ ] Pass [ ] Fail

---

#### TC-103: Practice Mode - Phone in Pocket
**Steps:**
1. Enter practice mode
2. Put phone in pocket
3. Shake hip/leg where phone is
4. Check if detection works

**Expected Result:**
- Gesture still detected through fabric
- Haptic feedback felt
- Counter updates correctly

**Status:** [ ] Pass [ ] Fail

---

#### TC-104: Gesture Timeout
**Steps:**
1. Enter practice mode
2. Shake once, wait 3 seconds
3. Shake once more

**Expected Result:**
- Counter resets after timeout
- Must complete 3 shakes within 2 seconds
- Old shakes don't count

**Status:** [ ] Pass [ ] Fail

---

#### TC-105: False Positive Prevention
**Steps:**
1. Enter practice mode
2. Walk around normally
3. Set phone down on table

**Expected Result:**
- Normal movement doesn't trigger detection
- No false alerts
- Only rapid shakes trigger

**Status:** [ ] Pass [ ] Fail

---

#### TC-106: Volume Button Gesture
**Steps:**
1. Select "Volume Down × 5"
2. Read instructions
3. Enter practice mode
4. Press volume down 5 times quickly

**Expected Result:**
- Tip explains Android-specific feature
- Detection confirms on compatible devices
- iOS shows appropriate message

**Status:** [ ] Pass [ ] Fail

---

### TEST SUITE 3: Alert Message Templates

#### TC-201: Edit Default Message
**Steps:**
1. Find default message text box
2. Change text to: "HELP! Emergency at [LOCATION]"
3. Tap "Save Default Message"

**Expected Result:**
- Success alert appears
- Preview updates immediately
- Message persists after app restart

**Status:** [ ] Pass [ ] Fail

---

#### TC-202: Insert Location Variable
**Steps:**
1. Clear message field
2. Type: "Help at "
3. Tap "[LOCATION]" variable button
4. Look at preview

**Expected Result:**
- [LOCATION] inserted at cursor
- Preview shows: "Help at 123 Main St, City, State"
- Address is realistic test data

**Status:** [ ] Pass [ ] Fail

---

#### TC-203: Insert Time Variable
**Steps:**
1. Add text: "Emergency at "
2. Tap "[TIME]" variable
3. Check preview

**Expected Result:**
- [TIME] inserted
- Preview shows current time (e.g., "9:45 PM")
- Time format matches device locale

**Status:** [ ] Pass [ ] Fail

---

#### TC-204: Custom Message Per Contact
**Steps:**
1. Find a contact (e.g., "Mom")
2. Tap "+ Add custom message for Mom"
3. Enter: "Mom, I need help at [LOCATION]. Call me!"
4. Tap "Save"

**Expected Result:**
- Custom message saved for that contact only
- Shows in contact's card
- Default message unchanged for other contacts

**Status:** [ ] Pass [ ] Fail

---

#### TC-205: Delete Custom Message
**Steps:**
1. Find contact with custom message
2. Tap "✕" button next to custom message
3. Confirm deletion

**Expected Result:**
- Custom message deleted
- Contact reverts to using default message
- Can add new custom message again

**Status:** [ ] Pass [ ] Fail

---

### TEST SUITE 4: Voice Settings

#### TC-301: Select Voice Type
**Steps:**
1. Tap each voice type: Female, Male, Neutral
2. Check visual selection
3. Restart app

**Expected Result:**
- Selected voice highlighted with blue border
- Selection persists after restart
- Checkmark badge appears on selected

**Status:** [ ] Pass [ ] Fail

---

#### TC-302: Select Voice Tone
**Steps:**
1. Tap each tone: Casual, Concerned, Professional
2. Read example phrases
3. Check selection

**Expected Result:**
- Radio button selected
- Example phrase shows for each tone
- Sample phrases list updates

**Status:** [ ] Pass [ ] Fail

---

#### TC-303: Adjust Volume
**Steps:**
1. Drag volume slider from 0% to 100%
2. Check percentage display
3. Set to 50%

**Expected Result:**
- Percentage updates in real-time
- Slider smooth and responsive
- Value between 0-100%

**Status:** [ ] Pass [ ] Fail

---

#### TC-304: Preview Voice
**Steps:**
1. Select: Female voice, Concerned tone
2. Set volume to 80%
3. Tap "▶️ Preview Voice"
4. Read alert message

**Expected Result:**
- Alert shows sample phrase
- States: "Playing: [phrase] Voice: female Tone: concerned"
- Playing indicator shows for 3 seconds
- (In production, would play actual audio)

**Status:** [ ] Pass [ ] Fail

---

#### TC-305: Voice Combinations
**Steps:**
1. Try all 9 combinations (3 types × 3 tones)
2. Preview each one
3. Check sample phrases

**Expected Result:**
- Each combination has unique sample phrases
- Phrases match selected tone personality
- All combinations work

**Status:** [ ] Pass [ ] Fail

---

### TEST SUITE 5: Decoy Screens

#### TC-401: Select Decoy Type
**Steps:**
1. Tap each decoy: Calculator, Weather, Notes, Browser
2. Check visual selection
3. Verify persistence

**Expected Result:**
- Radio button updates
- Selection saves
- Descriptions accurate

**Status:** [ ] Pass [ ] Fail

---

#### TC-402: Practice Calculator Decoy
**Steps:**
1. Select Calculator
2. Tap "👁️ Try Decoy Screen"
3. Confirm start
4. View decoy screen

**Expected Result:**
- Full-screen calculator displays
- Looks like real calculator app
- All buttons visible
- Exit zone in top-left corner

**Status:** [ ] Pass [ ] Fail

---

#### TC-403: Exit Decoy Screen
**Steps:**
1. Enter calculator decoy practice
2. Tap top-left corner 3 times rapidly
3. Watch counter

**Expected Result:**
- Counter shows "1/3", "2/3", "3/3"
- After 3 taps, exits to settings
- "Practice Mode Ended" alert appears

**Status:** [ ] Pass [ ] Fail

---

#### TC-404: Weather Decoy Realism
**Steps:**
1. Select Weather decoy
2. Practice mode
3. Examine UI elements

**Expected Result:**
- Shows realistic city, temperature
- Weather icon displayed
- 5-day forecast visible
- Looks like genuine weather app

**Status:** [ ] Pass [ ] Fail

---

#### TC-405: Notes Decoy
**Steps:**
1. Select Notes decoy
2. Enter practice
3. Check content

**Expected Result:**
- Shopping list displayed
- Items look natural
- Input field at bottom
- Appears as real notes app

**Status:** [ ] Pass [ ] Fail

---

#### TC-406: Browser Decoy
**Steps:**
1. Select Browser
2. Practice mode
3. Read article

**Expected Result:**
- URL bar at top
- News article headline
- Realistic content
- Scrollable text

**Status:** [ ] Pass [ ] Fail

---

### TEST SUITE 6: Privacy Settings

#### TC-501: Auto-Delete Options
**Steps:**
1. Select "24 hours"
2. Then select "7 days"
3. Then "Never delete"

**Expected Result:**
- Radio button updates each time
- Alert confirms each selection
- Settings persist

**Status:** [ ] Pass [ ] Fail

---

#### TC-502: Clear All Data
**Steps:**
1. Tap "🗑️ Clear All Location Data Now"
2. Read confirmation dialog
3. Tap "Delete"

**Expected Result:**
- Confirmation appears with warning
- "Cancel" option available
- On delete, success message shows
- Button disabled during deletion

**Status:** [ ] Pass [ ] Fail

---

#### TC-503: Cancel Clear Data
**Steps:**
1. Tap clear data button
2. Tap "Cancel" on confirmation

**Expected Result:**
- Dialog dismisses
- No data deleted
- Returns to settings

**Status:** [ ] Pass [ ] Fail

---

#### TC-504: Location Sharing Visibility
**Steps:**
1. Select each sharing option
2. Try "Anonymous safety network"

**Expected Result:**
- Can select "Emergency contacts only"
- Can select "Campus security only"
- "Anonymous" shows "Coming Soon" badge and alert
- Disabled options cannot be selected

**Status:** [ ] Pass [ ] Fail

---

#### TC-505: Export Data
**Steps:**
1. Tap "📥 Export Location History"
2. Read response

**Expected Result:**
- Shows "Coming Soon" alert
- Button works but feature not implemented yet

**Status:** [ ] Pass [ ] Fail

---

#### TC-506: Privacy Information Display
**Steps:**
1. Scroll to privacy info box
2. Read all bullet points
3. Tap "Read full Privacy Policy"

**Expected Result:**
- All 5 privacy points visible
- Link is clickable
- Information clear and accurate

**Status:** [ ] Pass [ ] Fail

---

#### TC-507: Status Indicators
**Steps:**
1. View status box at bottom
2. Check each indicator

**Expected Result:**
- Location Services: ✅ Active
- Last Update: Shows current time
- Storage Used: Shows data size (e.g., "2.3 MB")
- All values realistic

**Status:** [ ] Pass [ ] Fail

---

## 🔄 Integration Tests

### INT-001: Settings Persistence
**Steps:**
1. Configure all settings (contacts, gesture, messages, voice, decoy, privacy)
2. Force close app
3. Reopen app
4. Check all settings

**Expected Result:**
- All settings exactly as left
- No data loss
- No corruption

**Status:** [ ] Pass [ ] Fail

---

### INT-002: Full Emergency Flow
**Steps:**
1. Add 2 emergency contacts
2. Set shake gesture
3. Customize alert message
4. Enable practice mode
5. Shake phone 3 times
6. Check both contacts receive test SMS

**Expected Result:**
- Gesture detected
- Both contacts get SMS
- Message includes location
- Decoy screen can activate (if implemented)

**Status:** [ ] Pass [ ] Fail

---

### INT-003: Cross-Feature Dependencies
**Steps:**
1. Add contact
2. Create custom message for that contact
3. Delete contact
4. Check custom messages

**Expected Result:**
- Custom message removed with contact
- No orphaned data
- No crashes

**Status:** [ ] Pass [ ] Fail

---

## 📊 Test Summary

Total Tests: 56
- Emergency Contacts: 7 tests
- Gesture Detection: 6 tests
- Alert Templates: 5 tests
- Voice Settings: 5 tests
- Decoy Screens: 6 tests
- Privacy Settings: 7 tests
- Integration: 3 tests

### Pass/Fail Criteria
- **Pass:** 100% of critical tests (TC-001 through TC-507)
- **Acceptable:** 95%+ pass rate with no critical failures
- **Fail:** Any security/safety feature broken

### Bug Reporting
For any failed test, document:
1. Test case number
2. Steps to reproduce
3. Expected vs actual result
4. Screenshots/videos if applicable
5. Device and OS version

## 🎯 Performance Benchmarks

| Metric | Target | Acceptable |
|--------|--------|-----------|
| Gesture detection latency | <200ms | <500ms |
| Settings save time | <100ms | <300ms |
| Decoy screen activation | <500ms | <1s |
| SMS send time | <5s | <10s |
| App cold start | <2s | <3s |

## ✅ Sign-Off

Tester: ___________________
Date: ___________________
Device: ___________________
OS Version: ___________________

Overall Result: [ ] PASS [ ] FAIL

Notes:
________________________________________
________________________________________
________________________________________
